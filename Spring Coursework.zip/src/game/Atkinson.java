package game;

import city.cs.engine.*;

import java.awt.event.ActionEvent;

public class Atkinson extends Referee {

    private int counter = 0;

    //outlines the body of Mike Dean
    public static final Shape Atkinson = new PolygonShape(
            -2.12f,-2.23f, 2.17f,-2.23f, 1.35f,0.4f, -0.11f,2.32f, -1.35f,0.14f, -2.1f,-2.05f);

    //sets Player 1's image
    public static final BodyImage image =
            new BodyImage("data/atkinsoncrop.png", 5f);

    public Atkinson(World w) {
        super(w,Atkinson);
        addImage(image);
        startWalking(3);
    }

}