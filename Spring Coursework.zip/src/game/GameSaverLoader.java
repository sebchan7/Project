package game;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class GameSaverLoader {

    public static void save(GameLevel level, String fileName)
            throws IOException {
        boolean append = true;
        FileWriter writer = null;
        try {
            writer = new FileWriter(fileName, append);
            writer.write(level.getLevelName() + "," + level.getScore1() + "," + level.getScore2() + "\n");
        } finally {
            if (writer != null) {
                writer.close();
            }
        }
    }

    public static GameLevel load(Game game, String file)
            throws IOException {
        FileReader fr = null;
        BufferedReader reader = null;
        try {
            System.out.println("Reading " + file + " ...");
            fr = new FileReader(file);
            reader = new BufferedReader(fr);
            String line = reader.readLine();

            System.out.println("Reading!");

            String[] tokens = line.split(",");

            String name = tokens[0];
            GameLevel level = null;
            if (name.equals("Level1")) {
                level = new Level1(game);
            } else if (name.equals("Level2")) {
                level = new Level2(game);
            } else if (name.equals("Level3")) {
                level = new Level3(game);
            }

            int score1 = Integer.parseInt(tokens[1]);
            int score2 = Integer.parseInt(tokens[2]);
            level.Score1 = score1;
            level.Score2 = score2;

            System.out.println("Finished loading!");
            return level;

        } finally {
            if (reader != null) {
                reader.close();
            }
            if (fr != null) {
                fr.close();
            }
        }
    }
}
