package game;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

    public class Player2Controller implements KeyListener {
        // Speed for player
        private static final float WALKING_SPEED = 15;

        private Player2 Player2;

        public Player2Controller(Player2 s){ Player2 = s; }

        @Override
        public void keyTyped(KeyEvent e) {
        }

        @Override
        //controls to make Player 2 move
        public void keyPressed(KeyEvent e) {
            int code = e.getKeyCode();
            if (code == KeyEvent.VK_A) {
                Player2.startWalking(-WALKING_SPEED);
            } else if (code == KeyEvent.VK_D) {
                Player2.startWalking(WALKING_SPEED);
            }
            else if (code == KeyEvent.VK_W){
                Player2.jump(WALKING_SPEED*1.1f);
            }
        }
        @Override
        //stops the player from moving when no key is pressed
        public void keyReleased(KeyEvent e) {
            int code = e.getKeyCode();
            if (code == KeyEvent.VK_A) {
                Player2.stopWalking();
            } else if (code == KeyEvent.VK_D) {
                Player2.stopWalking();
            }
        }
        public void updateStudent(Player Player2) {
            this.Player2 = (game.Player2) Player2;
        }
    }

