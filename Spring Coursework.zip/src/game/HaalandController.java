package game;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class HaalandController implements KeyListener {
    // Speed for player
    private static final float WALKING_SPEED = 15;

    private Haaland Haaland;

    public HaalandController(Haaland s) {
        Haaland = s;
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    //controls to make Haaland move
    public void keyPressed(KeyEvent e) {
        int code = e.getKeyCode();
        // other key commands omitted
        if (code == KeyEvent.VK_J) {
            Haaland.startWalking(-WALKING_SPEED);
        } else if (code == KeyEvent.VK_L) {
            Haaland.startWalking(WALKING_SPEED);
        }
    }

    @Override
    //stops Haaland from moving when no key is pressed
    public void keyReleased(KeyEvent e) {
        int code = e.getKeyCode();
        if (code == KeyEvent.VK_J) {
            Haaland.stopWalking();
        } else if (code == KeyEvent.VK_L) {
            Haaland.stopWalking();
        } else if (code == KeyEvent.VK_I) {
            Haaland.jump(WALKING_SPEED * 1.1f);
        }
    }

    public void updateStudent(Haaland Haaland) {
        this.Haaland = Haaland;
    }
}
