package game;//package game;

import city.cs.engine.BodyImage;
import city.cs.engine.PolygonShape;
import city.cs.engine.Shape;
import city.cs.engine.World;

public class Mbappe extends Player {
    //sets the shape for Mbappe
    public static final Shape MbappeShape = new PolygonShape(
            -1.13f,0.26f, -0.05f,1.75f, 1.06f,0.31f, 1.05f,-1.75f, -1.33f,-1.76f, -1.17f,0.2f);

    //sets the image for Mbappe
    public static final BodyImage image =
            new BodyImage("data/mbappecrop.png", 7f);

    public Mbappe(World w) {
        super(w, MbappeShape);
        addImage(image);
    }
}
