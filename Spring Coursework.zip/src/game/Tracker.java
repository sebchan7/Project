package game;

import city.cs.engine.StepEvent;
import city.cs.engine.StepListener;
import org.jbox2d.common.Vec2;

public class Tracker implements StepListener {
    private GameView view;
    private Player Player1;
    public Tracker(GameView view, Player Player1) {
        this.view = view;
        this.Player1 = Player1;
    }
    public void preStep(StepEvent e) {}
    public void postStep(StepEvent e) {
        view.setCentre(new Vec2(Player1.getPosition()));
    }
}