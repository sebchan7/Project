package game;

import city.cs.engine.BodyImage;
import city.cs.engine.Shape;
import city.cs.engine.Walker;
import city.cs.engine.World;
import java.awt.*;

public abstract class Player extends Walker {

    public BodyImage  image;
    public Shape Shape;

    public Player(World w, Shape s) {
        super(w, s);
    }

}

