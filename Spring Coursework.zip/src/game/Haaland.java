package game;//package game;

import city.cs.engine.BodyImage;
import city.cs.engine.Shape;
import city.cs.engine.World;
import city.cs.engine.PolygonShape;
import game.Player;

public class Haaland extends Player {
    //sets the shape of Haaland
    public static final Shape HaalandShape = new PolygonShape(
            -0.76f,2.45f, 0.87f,2.34f, 2.34f,-2.34f, -2.2f,-2.36f, -1.95f,-0.12f, -0.86f,2.34f);

    //sets the image for Haaland
    public static final BodyImage image =
            new BodyImage("data/haalandcrop.png", 5f);

    public Haaland(World w) {
        super(w, HaalandShape);
        addImage(image);
    }
}
