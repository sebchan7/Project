package game;

import city.cs.engine.BoxShape;
import city.cs.engine.Shape;
import city.cs.engine.StaticBody;
import org.jbox2d.common.Vec2;

import javax.swing.*;
import java.awt.*;

public class Level3 extends GameLevel {

    public Level3(Game game) {
        super(game);
        //adds a ball to the level
        ball = new Football(this);
        ball.setPosition(new Vec2(-5, 5));
        //the floor of the level is created
        Shape shape = new BoxShape(40, 0.25f);
        StaticBody ground = new StaticBody(this, shape);
        ground.setPosition(new Vec2(0f, -22.50f));

        //the walls of the level are created
        Shape wallShape = new BoxShape(0.5f, 20f);
        StaticBody wall1 = new StaticBody(this, wallShape);
        wall1.setPosition(new Vec2(-40.5f, -5));
        StaticBody wall2 = new StaticBody(this, wallShape);
        wall2.setPosition(new Vec2(40.5f, -5));

        //determines which player goes from level 2 to level 3
        if (FootballPickup.haalandWin) {
            getPlayer2().destroy();
            getPlayer1().destroy();
            getHaaland().setPosition(new Vec2(-20, -22));
            getHaaland().addCollisionListener(new FootballPickup(ball, ground, wall1, wall2, this, game));
        }
        if (FootballPickup.sakaWin == 2) {
            getHaaland().destroy();
            getPlayer2().destroy();
            getPlayer1().setPosition(new Vec2(-20, -22));
            getPlayer1().addCollisionListener(new FootballPickup(ball, ground, wall1, wall2, this, game));

        }
        if (FootballPickup.greenwoodWin == 2) {
            getHaaland().destroy();
            getPlayer1().destroy();
            getPlayer2().setPosition(new Vec2(-20, -22));
            getPlayer2().addCollisionListener(new FootballPickup(ball, ground, wall1, wall2, this, game));
        }
        //Mbappe's position is set and his collision listener is added
        getMbappe().setPosition(new Vec2(12, -22));
        getAtkinson().setPosition(new Vec2(15, 10));
        getDean().setPosition(new Vec2(10, 10));
        getDean().addCollisionListener(new FootballPickup(ball, ground, wall1, wall2, this, game));
        getAtkinson().addCollisionListener(new FootballPickup(ball, ground, wall1, wall2, this, game));
        getMbappe().addCollisionListener(new FootballPickup(ball, ground, wall1, wall2, this, game));
        //the collision listener for the walls and floor is added
        ground.addCollisionListener(new FootballPickup(ball, ground, wall1, wall2, this, game));
        wall1.addCollisionListener(new FootballPickup(ball, ground, wall1, wall2, this, game));
        wall2.addCollisionListener(new FootballPickup(ball, ground, wall1, wall2, this, game));

        new java.util.Timer().schedule(
                new java.util.TimerTask() {
                    @Override
                    public void run() {
                        Atkinson.walkLeft();
                    }
                },
                5000
        );

        new java.util.Timer().schedule(
                new java.util.TimerTask() {
                    @Override
                    public void run() {
                        Dean.walkRight();
                    }
                },
                5000
        );
    }

    //determines what score is needed to win the game
    @Override
    public boolean isComplete() {
        if (FootballPickup.sakaWin==2 && Score1 >=5){
            System.out.println("Saka wins!");
            System.exit(0);
        }
        if (FootballPickup.sakaWin==2 && Score2 >=5){
            System.out.println("Mbappe wins!");
            System.exit(0);
        }
        if (FootballPickup.sakaWin == 1 && FootballPickup.haalandWin && Score1 >= 5){
            System.out.println("Mbappe wins!");
            System.exit(0);
        }
        if (FootballPickup.sakaWin == 1 && FootballPickup.haalandWin && Score2 >= 5){
            System.out.println("Haaland wins!");
            System.exit(0);
        }
        if (FootballPickup.greenwoodWin ==2 && Score1 >=5){
            System.out.println("Mbappe wins!");
            System.exit(0);
        }
        if (FootballPickup.greenwoodWin ==2 && Score2 >=5){
            System.out.println("Greenwood wins!");
            System.exit(0);
        }
        if (FootballPickup.greenwoodWin == 1 && FootballPickup.haalandWin && Score1 >= 5){
            System.out.println("Haaland wins!");
            System.exit(0);
        }
        if (FootballPickup.greenwoodWin == 1 && FootballPickup.haalandWin && Score2 >= 5){
            System.out.println("Mbappe wins!");
            System.exit(0);
        }
        else ;
        return false;
    }

    //sets the background for level 3
    @Override
    public Image paintBackground() {
        Image background = new ImageIcon("data/psg.png").getImage();
        return background;
    }

    @Override
    public String getLevelName() {
        return "Level3";
    }

    @Override
    public int getScore1() {
        return Score1;
    }

    @Override
    public int getScore2() {
        return Score2;
    }
}
