package game;

import city.cs.engine.CollisionEvent;
import city.cs.engine.CollisionListener;
import city.cs.engine.SoundClip;
import city.cs.engine.StaticBody;
import org.jbox2d.common.Vec2;

import java.io.IOException;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;


public class FootballPickup implements CollisionListener {
    public static int sakaWin = 0;
    public static int greenwoodWin = 0;
    public static boolean haalandWin = false;
    public static boolean mbappeWin = false;

    private GameLevel level;
    private Game game;
    private Football ball;
    private StaticBody ground;
    private StaticBody wall1;
    private StaticBody wall2;

    public FootballPickup(Football b, StaticBody g, StaticBody w, StaticBody y, GameLevel level, Game game) {
        this.ball = b;
        this.ground = g;
        this.wall1 = w;
        this.wall2 = y;
        this.game = game;
        this.level = level;
    }

    @Override
    public void collide(CollisionEvent e) {

        /**
         *when the ball is touched by player 1 the score increments, an impulse is applied to the ball, and a kick sound is played
         */
        if (e.getReportingBody() instanceof Player1 && e.getOtherBody() instanceof Football) {
            ball.applyImpulse(new Vec2(0, 25));
            level.Score1++;
            System.out.println(level.getScore1());
            if (level.isComplete()) {
                sakaWin++;
                game.goToNextLevel();
            }
            try {
                SoundClip kickSound = new SoundClip("data/kick.wav");
                kickSound.setVolume(2);
                kickSound.play();

            } catch (UnsupportedAudioFileException | IOException | LineUnavailableException f) {
                System.out.println(f);
            }
        }
        /**
         *when the ball is touched by player 2 the score increments, an impulse is applied to the ball, and a kick sound is played
         */
        if (e.getReportingBody() instanceof Player2 && e.getOtherBody() instanceof Football) {
            ball.applyImpulse(new Vec2(0, 25));
            level.Score2++;
            System.out.println(level.Score2);
            if (level.isComplete()) {
                greenwoodWin++;
                game.goToNextLevel();
                level.Score1 = 0;
                level.Score2 = 0;
            }
            try {
                SoundClip kickSound = new SoundClip("data/kick.wav");
                kickSound.play();
                kickSound.setVolume(2);
            } catch (UnsupportedAudioFileException | IOException | LineUnavailableException f) {
                System.out.println(f);
            }
        }
        /**
         *when the ball is touched by Haaland the score increments, an impulse is applied to the ball, and a kick sound is played
         */
        if (e.getReportingBody() instanceof Haaland && e.getOtherBody() instanceof Football) {
            ball.applyImpulse(new Vec2(0, 25));
            try {
                SoundClip kickSound = new SoundClip("data/kick.wav");
                kickSound.play();
                kickSound.setVolume(2);
            } catch (UnsupportedAudioFileException | IOException | LineUnavailableException f) {
                System.out.println(f);
            }
            /**
             *determines which Score relates to Haaland
             */
            if (sakaWin == 1) {
                level.Score2++;
                System.out.println(level.Score2);
                if (level.isComplete()) {
                    haalandWin = true;
                    game.goToNextLevel();
                }
                }
                else {
                    level.Score1++;
                    System.out.println(level.Score1);
                    if (level.isComplete()) {
                        haalandWin = true;
                        game.goToNextLevel();
                    }
                }
        }
        /**
         *when the ball is touched by Mbappe the score increments, an impulse is applied to the ball, and a kick sound is played
         */
        if (e.getReportingBody() instanceof Mbappe && e.getOtherBody() instanceof Football) {
            ball.applyImpulse(new Vec2(0, 25));
            try {
                SoundClip kickSound = new SoundClip("data/kick.wav");
                kickSound.play();
                kickSound.setVolume(2);
            } catch (UnsupportedAudioFileException | IOException | LineUnavailableException f) {
                System.out.println(f);
            }
            /**
             *determines which Score relates to Mbappe
             */
            if (haalandWin && sakaWin == 1) {
                level.Score1++;
                System.out.println(level.Score1);
                if (level.isComplete()) {
                    mbappeWin = true;
                    game.goToNextLevel();
                }
            }
            if (haalandWin && sakaWin == 0) {
                level.Score2++;
                if (level.isComplete()) {
                    mbappeWin = true;
                    game.goToNextLevel();
                }
            }
            if (sakaWin == 1) {
                level.Score2++;

                if (level.isComplete()) {
                    mbappeWin = true;
                    game.goToNextLevel();
                }
            } else {
                level.Score1++;
                if (level.isComplete()) {
                    mbappeWin = true;
                    game.goToNextLevel();
                }
            }
        }

        /**
         *applies an impulse to the ball when it touches either of the walls or the floor
         */
        if (e.getReportingBody() == ground && e.getOtherBody() instanceof Football) {
            ball.applyImpulse(new Vec2(0, 50));
        }
        if (e.getReportingBody() == wall1 && e.getOtherBody() instanceof Football) {
            ball.applyImpulse(new Vec2(20, 50));
        }
        if (e.getReportingBody() == wall2 && e.getOtherBody() instanceof Football) {
            ball.applyImpulse(new Vec2(-20, 50));
        }

        /**
         *determines who wins the game if a referee is touched
         */
        if (e.getReportingBody() instanceof Atkinson && e.getOtherBody() instanceof Mbappe) {
            if (sakaWin == 1 && haalandWin) {
                System.out.println("Haaland wins!");
                System.exit(0);
            } else if (sakaWin == 2) {
                System.out.println("Saka wins!");
                System.exit(0);
            } else {
                System.out.println("Greenwood wins!");
                System.exit(0);

            }
        }
        if (e.getReportingBody() instanceof Dean && e.getOtherBody() instanceof Mbappe) {
            if (sakaWin == 1 && haalandWin) {
                System.out.println("Haaland wins!");
                System.exit(0);
            } else if (sakaWin == 2) {
                System.out.println("Saka wins!");
                System.exit(0);
            } else {
                System.out.println("Greenwood wins!");
                System.exit(0);
            }
        }
        if (e.getReportingBody() instanceof Atkinson && e.getOtherBody() instanceof Haaland) {
            if (sakaWin == 1 && haalandWin) {
                System.out.println("Mbappe wins!");
                System.exit(0);
            } else if (sakaWin == 1) {
                System.out.println("Saka wins!");
                System.exit(0);
            } else {
                System.out.println("Greenwood wins!");
                System.exit(0);
            }
        }
        if (e.getReportingBody() instanceof Dean && e.getOtherBody() instanceof Haaland) {
            System.out.println("Mbappe wins!");
            System.exit(0);
        }
        if (e.getReportingBody() instanceof Dean && e.getOtherBody() instanceof Player1) {
            System.out.println("Mbappe wins!");
            System.exit(0);
        }
        if (e.getReportingBody() instanceof Dean && e.getOtherBody() instanceof Player2) {
            System.out.println("Mbappe wins!");
            System.out.println("d");
            System.exit(0);
        }

        if (e.getReportingBody() instanceof Atkinson && e.getOtherBody() instanceof Player1) {
            if (sakaWin == 1) {
                System.out.println("Haaland wins!");
                System.exit(0);
            } else if (sakaWin == 2) {
                System.out.println("Mbappe wins!");
                System.exit(0);
            }
        }

        if (e.getReportingBody() instanceof Atkinson && e.getOtherBody() instanceof Player2) {
            if (greenwoodWin == 1) {
                System.out.println("Haaland wins!");
                System.exit(0);
            }
            if (greenwoodWin == 2) {
                System.out.println("Mbappe wins!");
                System.out.println("a");
                System.exit(0);
            }

        }

    }
}






