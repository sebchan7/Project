package game;

import city.cs.engine.*;
import city.cs.engine.Shape;
import org.jbox2d.common.Vec2;

import javax.naming.ReferralException;
import javax.swing.*;
import java.awt.*;

public class  Level2 extends GameLevel {

    private int counter = 0;

    public Level2(Game game) {
        super(game);
        //removes Mbappe from level 2
        getMbappe().destroy();
        getDean().destroy();
        //adds a referee to the level
        //adds a ball to the level
        ball = new Football(this);
        ball.setPosition(new Vec2(-5, 5));

        //the floor for the level is created
        Shape shape = new BoxShape(40, 0.25f);
        StaticBody ground = new StaticBody(this, shape);
        ground.setPosition(new Vec2(0f, -22.50f));
        //the walls for the level are created
        Shape wallShape = new BoxShape(0.5f, 20f);
        StaticBody wall1 = new StaticBody(this, wallShape);
        wall1.setPosition(new Vec2(-40.5f, -5));
        StaticBody wall2 = new StaticBody(this, wallShape);
        wall2.setPosition(new Vec2(40.5f, -5));


        //determines which player from level 1 gets through to level 2
        if (FootballPickup.sakaWin == 1) {
            getPlayer2().destroy();
            getPlayer1().setPosition(new Vec2(-20, -22));
            getPlayer1().addCollisionListener(new FootballPickup(ball, ground, wall1, wall2, this, game));

        } else {
            getPlayer1().destroy();
            getPlayer2().setPosition(new Vec2(-20, -22));
            getPlayer2().addCollisionListener(new FootballPickup(ball, ground, wall1, wall2, this, game));

            //Haaland's collision listener is created

        }
        getHaaland().setPosition(new Vec2(12, -22));
        getAtkinson().setPosition(new Vec2(0,10));
        getAtkinson().addCollisionListener(new FootballPickup(ball, ground, wall1, wall2, this, game));
        getHaaland().addCollisionListener(new FootballPickup(ball, ground, wall1, wall2, this, game));

        //the collision listeners for the walls for wall and floor
        wall1.addCollisionListener(new FootballPickup(ball, ground, wall1, wall2, this, game));
        wall2.addCollisionListener(new FootballPickup(ball, ground, wall1, wall2, this, game));
        ground.addCollisionListener(new FootballPickup(ball, ground, wall1, wall2, this, game));


        new java.util.Timer().schedule(
                new java.util.TimerTask() {
                    @Override
                    public void run() {
                        Atkinson.walkLeft();
                    }
                },
                5000
        );
    }

    //sets the winning score for level 2
    @Override
    public boolean isComplete() {
        if (Score1 >= 3)
            return true;
        if (Score2 >= 3)
            return true;
        else ;
        return false;
    }

    //sets the background for level 2
    @Override
    public Image paintBackground() {
        Image background = new ImageIcon("data/dortmundcrop.png").getImage();
        return background;
    }

    @Override
    public String getLevelName(){
        return "Level2";
    }

    @Override
    public int getScore1() {
        return Score1;
    }

    @Override
    public int getScore2() {
        return Score2;
    }

    }

    //@Override
    //public void postStep(StepEvent stepEvent) {


