package game;

import city.cs.engine.SoundClip;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

import city.cs.engine.DebugViewer;

import javax.swing.*;
import java.awt.*;
import java.util.logging.Level;

/**
 * A world with some bodies.
 */
public class Game {

    private Timer timer;
    private GameLevel level;
    private GameView view;
    private SoundClip gameMusic;


    /**
     * The World in which the bodies move and interact.
     */
    private Player1Controller controller1;
    private Player2Controller controller2;
    private HaalandController controller3;
    private MbappeController controller4;

    JFrame window;
    Container con;
    JPanel titleNamePanel, startButtonPanel, quitButtonPanel, sakaPanel, greenwoodPanel, haalandPanel, mbappePanel, warningPanel;
    JLabel titleNameLabel, sakaInstructions, greenwoodInstructions, haalandInstructions, mbappeInstructions, warningMessage;


    Font titleFont = new Font("Times New Roman", Font.PLAIN, 60);
    Font normalFont = new Font("Times New Roman", Font.PLAIN, 25);
    JButton startButton;
    JButton quitButton;

    /**
     *
     */


    /**
     * Initialise a new Game.
     */
    public Game() {

        window = new JFrame();
        window.setSize(940, 460);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.getContentPane().setBackground(Color.black);

        window.setLayout(null);
        window.setVisible(true);
        con = window.getContentPane();

        titleNamePanel = new JPanel();
        titleNamePanel.setBounds(120, 100, 750, 75);
        titleNamePanel.setBackground(Color.darkGray);
        titleNameLabel = new JLabel("Saka On Top!");
        titleNameLabel.setForeground(Color.white);
        titleNameLabel.setFont(titleFont);

        startButtonPanel = new JPanel();
        startButtonPanel.setBounds(290, 310, 150, 50);
        startButtonPanel.setBackground(Color.lightGray);

        quitButtonPanel = new JPanel();
        quitButtonPanel.setBounds(530, 310, 150, 50);
        quitButtonPanel.setBackground(Color.lightGray);

        startButton = new JButton("START");
        startButton.setBackground(Color.white);
        startButton.setForeground(Color.black);
        startButton.setFont(normalFont);
        startButton.addActionListener(e -> createGameButton());

        quitButton = new JButton("QUIT");
        quitButton.setBackground(Color.white);
        quitButton.setForeground(Color.black);
        quitButton.setFont(normalFont);
        quitButton.addActionListener(e -> System.exit(0));

        titleNamePanel.add(titleNameLabel);
        startButtonPanel.add(startButton);
        quitButtonPanel.add(quitButton);

        con.add(titleNamePanel);
        con.add(startButtonPanel);
        con.add(quitButtonPanel);
    }

    public void pause() {
        level.stop();
    }

    public void start() {
        level.start();
    }

    public void save() {
        try {
            GameSaverLoader.save(level, "data/save.txt");
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
    }

    public void load() {
        try {
            GameLevel level = GameSaverLoader.load(this, "data/save.txt");
            setLevel(level);

        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
    }

    private void setLevel(GameLevel level) {
        this.level.stop(); // Stop the level
        gameMusic.stop();
        this.level = level;
        // create the new level
        if (level instanceof Level1) {
            this.level = new Level1(this);
            view.Level1Image(); // Change the background
            view.setZoom(20); // Change the zoom
            controller1.updateStudent(level.getPlayer1());
            controller2.updateStudent(level.getPlayer2());
        }
        else if (level instanceof Level2) {
            this.level = new Level2(this);
            view.Level2Image(); // Change the background
            view.setZoom(20); // Change the zoom
            controller1.updateStudent(level.getPlayer1());
            controller2.updateStudent(level.getPlayer2());
            controller3.updateStudent(level.getHaaland());
        }
        if (level instanceof Level3) {
            this.level = new Level3(this);
            view.Level3Image(); // Change the background
            view.setZoom(20); // Change the zoom
            controller1.updateStudent(level.getPlayer1());
            controller2.updateStudent(level.getPlayer2());
            controller3.updateStudent(level.getHaaland());
            controller4.updateStudent(level.getMbappe());
        }
        view.setWorld(level);
        view.updateView(level);
        level.start(); // start the level
    }

    public void createGameButton() {
        window.dispose();
        createGame();
    }

    public void helpScreen() {
        window = new JFrame();
        window.setSize(940, 460);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.getContentPane().setBackground(Color.black);

        window.setLayout(null);
        window.setVisible(true);
        con = window.getContentPane();

        sakaPanel = new JPanel();
        sakaPanel.setBounds(50, 20, 750, 40);
        sakaPanel.setBackground(Color.darkGray);
        sakaInstructions = new JLabel("Saka controls:UP LEFT RIGHT");
        sakaInstructions.setForeground(Color.white);
        sakaInstructions.setFont(normalFont);

        greenwoodPanel = new JPanel();
        greenwoodPanel.setBounds(50, 65, 750, 40);
        greenwoodPanel.setBackground(Color.darkGray);
        greenwoodInstructions = new JLabel("Greenwood controls:W A D");
        greenwoodInstructions.setForeground(Color.white);
        greenwoodInstructions.setFont(normalFont);

        haalandPanel = new JPanel();
        haalandPanel.setBounds(50, 110, 750, 40);
        haalandPanel.setBackground(Color.darkGray);
        haalandInstructions = new JLabel("Haaland controls: I J L");
        haalandInstructions.setForeground(Color.white);
        haalandInstructions.setFont(normalFont);

        mbappePanel = new JPanel();
        mbappePanel.setBounds(50, 155, 750, 40);
        mbappePanel.setBackground(Color.darkGray);
        mbappeInstructions = new JLabel("Mbappe controls: T F H");
        mbappeInstructions.setForeground(Color.white);
        mbappeInstructions.setFont(normalFont);

        mbappePanel = new JPanel();
        mbappePanel.setBounds(50, 155, 750, 40);
        mbappePanel.setBackground(Color.darkGray);
        mbappeInstructions = new JLabel("Mbappe controls: T F H");
        mbappeInstructions.setForeground(Color.white);
        mbappeInstructions.setFont(normalFont);

        warningPanel = new JPanel();
        warningPanel.setBounds(50, 200, 750, 40);
        warningPanel.setBackground(Color.darkGray);
        warningMessage = new JLabel("DONT TOUCH THE REFEREE!!!");
        warningMessage.setForeground(Color.white);
        warningMessage.setFont(normalFont);

        sakaPanel.add(sakaInstructions);
        greenwoodPanel.add(greenwoodInstructions);
        haalandPanel.add(haalandInstructions);
        mbappePanel.add(mbappeInstructions);
        warningPanel.add(warningMessage);

        con.add(sakaPanel);
        con.add(greenwoodPanel);
        con.add(haalandPanel);
        con.add(mbappePanel);
        con.add(warningPanel);
    }

    public void createGame() {

        // make the world
        level = new Level1(this);
        view = new GameView(level, level, 1600, 900);
        view.setZoom(20);
        controller1 = new Player1Controller(level.getPlayer1());
        view.addKeyListener(controller1);
        controller2 = new Player2Controller(level.getPlayer2());
        view.addKeyListener(controller2);
        controller3 = new HaalandController(level.getHaaland());
        view.addKeyListener(controller3);
        controller4 = new MbappeController(level.getMbappe());
        view.addKeyListener(controller4);

        try {
            gameMusic = new SoundClip("data/cheering.wav");
            gameMusic.loop();
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            System.out.println(e);
        }
        // make a view

        // uncomment this to draw a 1-metre grid over the view
        // view.setGridResolution(1);
        // add some mouse actions
        // add this to the view, so coordinates are relative to the view
        view.addMouseListener(new GiveFocus(view));
        //world.addStepListener(new Tracker(view, world.getStudent()));
        // add the view to a frame (Java top level window)
        final JFrame frame = new JFrame("Saka On Top");
        frame.add(view);
        ControlPanel buttons = new ControlPanel(this);
        frame.add(buttons.getMainPanel(), BorderLayout.WEST);
        // enable the frame to quit the application
        // when the x button is pressed
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationByPlatform(true);
        // don't let the frame be resized
        frame.setResizable(false);
        // size the frame to fit the world view
        frame.pack();
        // finally, make the frame visible
        frame.setVisible(true);
        // JFrame debugView = new DebugViewer(world, 1600, 900);
    }

    public void goToNextLevel() {

        if (level instanceof Level1) {
            //stop the current level
            level.stop();
            //create the new (appropriate) level
            //level now refers to new level
            level = new Level2(this);
            //change the view to look into new level
            view.setWorld(level);
            view.updateView(level);
            view.Level2Image();
            //change the controller to control the
            //student in the new world
            controller1.updateStudent(level.getPlayer1());
            controller2.updateStudent(level.getPlayer2());
            controller3.updateStudent(level.getHaaland());
            controller4.updateStudent(level.getMbappe());
            //start the simulation in the new level
            level.start();
        } else if (level instanceof Level2) {
            level.stop();
            level = new Level3(this);
            view.setWorld(level);
            view.updateView(level);
            view.Level3Image();
            controller1.updateStudent(level.getPlayer1());
            controller2.updateStudent(level.getPlayer2());
            controller3.updateStudent(level.getHaaland());
            controller4.updateStudent(level.getMbappe());
            level.start();
        //} else if (level instanceof Level3) {

           // if (FootballPickup.mbappeWin) {
            //    System.out.println("Mbappe wins");
          //  }
           // System.out.println("Game Finished");
        }
    }

    /**
     * Run the game.
     */
    public static void main(String[] args) {
        new Game();
    }
}
