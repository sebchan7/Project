package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

public class Football extends DynamicBody {
    //sets the shape of the football
    private static final Shape footballShape = new CircleShape(1);
    //sets the image for the football
    private static final BodyImage image =
            new BodyImage("data/footballcrop.png", 2f);

    public Football(World w) {
        super(w,footballShape);
        addImage(image);

    }
    }

