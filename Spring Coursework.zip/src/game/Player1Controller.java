package game;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;

public class Player1Controller implements KeyListener {
        // Speed for player
        private static final float WALKING_SPEED = 15;

        private Player1 Player1;
        private Game game;

        public Player1Controller(Player1 s) { Player1 = s; }

        @Override
        public void keyTyped(KeyEvent e) {
        }

        @Override
        //controls to make Player 1 move
        public void keyPressed(KeyEvent e) {
            int code = e.getKeyCode();
            if (code == KeyEvent.VK_LEFT) {
                Player1.startWalking(-WALKING_SPEED);
            } else if (code == KeyEvent.VK_RIGHT) {
                Player1.startWalking(WALKING_SPEED);
            }
        }

        @Override
        //stops the player from moving when no key is pressed
        public void keyReleased(KeyEvent e) {
            int code = e.getKeyCode();
            if (code == KeyEvent.VK_LEFT) {
                Player1.stopWalking();
            } else if (code == KeyEvent.VK_RIGHT) {
                Player1.stopWalking();
            } else if (code == KeyEvent.VK_UP) {
                Player1.jump(WALKING_SPEED * 1.1f);
            }
        }


            public void updateStudent (Player Player1){
                this.Player1 = (game.Player1) Player1;
            }
        }
