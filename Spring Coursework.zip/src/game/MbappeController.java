package game;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class MbappeController implements KeyListener {
    // Speed for player
    private static final float WALKING_SPEED = 15;

    private Mbappe Mbappe;

    public MbappeController(Mbappe s) {
        Mbappe = s;
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    //controls to make Mbappe move
    public void keyPressed(KeyEvent e) {
        int code = e.getKeyCode();
        // other key commands omitted
        if (code == KeyEvent.VK_F) {
            Mbappe.startWalking(-WALKING_SPEED);
        } else if (code == KeyEvent.VK_H) {
            Mbappe.startWalking(WALKING_SPEED);
        }
    }

    @Override
    //stops Mbappe from moving when no key is pressed
    public void keyReleased(KeyEvent e) {
        int code = e.getKeyCode();
        if (code == KeyEvent.VK_F) {
            Mbappe.stopWalking();
        } else if (code == KeyEvent.VK_H) {
            Mbappe.stopWalking();
        } else if (code == KeyEvent.VK_T) {
            Mbappe.jump(WALKING_SPEED * 1.1f);
        }
    }
    public void updateStudent(Mbappe Mbappe) {
        this.Mbappe = Mbappe;
    }
}
