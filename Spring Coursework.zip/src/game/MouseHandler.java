package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class MouseHandler extends MouseAdapter {

    private GameLevel world;
    private GameView view;

    public MouseHandler(GameLevel w, GameView v){
        world = w;
        view = v;
    }

//    @Override
//    public void mousePressed(MouseEvent e) {
//        //create Books and add them to world
//        Football ball = new Football(world);
//        //get the mouse coordinates
//        Point mousePoint = e.getPoint();
//        //transform them to world coordinates
//        Vec2 worldPoint = view.viewToWorld(mousePoint);
//        //position the books
//        ball.setPosition(worldPoint);
//        FootballPickup pickupBall = new FootballPickup(ball);
//        ball.addCollisionListener(pickupBall);
//
//    }

    //we have to implement the other methods to satisfy
    //the interface, but we can leave them empty.

    @Override
    public void mouseClicked(MouseEvent e) {
    }
    @Override
    public void mouseReleased(MouseEvent e) {
    }
    @Override
    public void mouseEntered(MouseEvent e) {
    }
    @Override
    public void mouseExited(MouseEvent e) {
    }
}
