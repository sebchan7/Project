package game;

import javax.swing.*;

public class ControlPanel extends javax.swing.JPanel{

    Game game;
    private JPanel mainPanel;
    private javax.swing.JButton quitButton;
    private javax.swing.JButton pauseButton;
    private javax.swing.JButton resumeButton;
    private JButton saveButton;
    private JButton loadButton;
    private JButton helpButton;

    public ControlPanel(Game game) {
        this.game = game;
        quitButton.addActionListener(e -> System.exit(0));
        pauseButton.addActionListener(e -> game.pause());
        resumeButton.addActionListener(e -> game.start());
        saveButton.addActionListener(e -> game.save());
        loadButton.addActionListener(e -> game.load());
        helpButton.addActionListener(e -> game.helpScreen());
    }

    private void JButton1ActionPerformed(java.awt.event.ActionEvent evt){
        System.out.println("Pause");
        game.pause();

    }
    public JPanel getMainPanel() {
        return mainPanel;
    }
}
