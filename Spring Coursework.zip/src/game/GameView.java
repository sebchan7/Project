package game;

import city.cs.engine.UserView;
import city.cs.engine.World;

import javax.swing.*;
import java.awt.*;

public class GameView extends UserView {
    private Image background;
    private GameLevel level;

    //image for level 1 is loaded
    public GameView(World w, GameLevel l, int width, int height) {
        super(w, width, height);
        this.level = l;
        background = new ImageIcon("data/emiratesresize.png").getImage();
    }

    public void updateView(GameLevel l) {
        this.level = l;
    }
    public void Level1Image(){
        background = new ImageIcon("data/emiratesresize.png").getImage();
    }

    //image for level 2 is loaded
    public void Level2Image(){
        background = new ImageIcon("data/dortmundresize.png").getImage();
    }

    //image for level 3 is loaded
    public void Level3Image(){
        background = new ImageIcon("data/psgresize.png").getImage();
    }

    @Override
    protected void paintBackground(Graphics2D g) {
        g.drawImage(background, 0, 0, this);
    }
    @Override
    protected void paintForeground(Graphics2D g) {
        //scores for the players are displayed
        g.setColor(Color.white);
        g.drawString("Score:" + (level.Score1),100,100);
        g.drawString("Score:" + (level.Score2),1450,100);
        //g.draw("Time:" + game.timer);
    }
}
