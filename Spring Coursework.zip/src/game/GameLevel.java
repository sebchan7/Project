package game;

import city.cs.engine.World;

import javax.swing.*;
import java.awt.*;

public abstract class GameLevel extends World{
    public Player1 player1;
    public Player2 player2;
    public Haaland haaland;
    public Football ball;
    public Mbappe Mbappe;
    public Dean Dean;
    public Atkinson Atkinson;
    public int Score1;
    public int Score2;

    public GameLevel(Game game) {
        player1 = new Player1(this);
        player2 = new Player2(this);
        haaland = new Haaland(this);
        Mbappe = new Mbappe(this);
        Dean = new Dean(this);
        Atkinson = new Atkinson(this);
        Score1 = 0;
        Score2 = 0;
    }

    public Player1 getPlayer1(){
        return player1;
    }
    public Player2 getPlayer2(){ return player2; }
    public Haaland getHaaland(){return haaland;}
    public Mbappe getMbappe(){return Mbappe;}
    public Dean getDean(){return Dean;}
    public Atkinson getAtkinson(){return Atkinson;}

    public abstract boolean isComplete();

    public abstract Image paintBackground();

    public abstract String getLevelName();
    public abstract int getScore1();
    public abstract int getScore2();
    //public abstract void refereeTimer(){
       //Timer timer = new Timer(1000)
    //}


}

