package game;

import city.cs.engine.BodyImage;
import city.cs.engine.PolygonShape;
import city.cs.engine.Shape;
import city.cs.engine.World;

public class Player2 extends Player {
    //outlines the body of Player 2
    public static final Shape Player2Shape = new PolygonShape(
            1.84f, 1.99f, 1.96f, -0.3f, 1.5f, -2.36f,
            -0.47f, -2.33f, -1.98f, 1.69f, 0.5f, 2.46f);
    //sets Player 2's image
    public static final BodyImage image =
            new BodyImage("data/greenwoodcrop.png", 5f);


    public Player2(World w) {
        super(w, Player2Shape);
        addImage(image);
    }
}
