package game;

import city.cs.engine.BoxShape;
import city.cs.engine.Shape;
import city.cs.engine.StaticBody;
import org.jbox2d.common.Vec2;
import javax.swing.*;
import java.awt.*;

public class Level1 extends GameLevel {

    public Level1(Game game) {
        super(game);

        //adds a ball to the level
        ball = new Football(this);
        //sets the position of the ball
        ball.setPosition(new Vec2(-5, 5));
        //removes the players that are not on level 1
        getAtkinson().destroy();
        getDean().destroy();
        getHaaland().destroy();
        getMbappe().destroy();
        //the floor for the level is created
        Shape shape = new BoxShape(40, 0.25f);
        StaticBody ground = new StaticBody(this, shape);
        ground.setPosition(new Vec2(0f, -22.50f));

        //the walls for the level are created
        Shape wallShape = new BoxShape(0.5f, 20f);
        StaticBody wall1 = new StaticBody(this, wallShape);
        wall1.setPosition(new Vec2(-40.5f, -5));

        StaticBody wall2 = new StaticBody(this, wallShape);
        wall2.setPosition(new Vec2(40.5f, -5));

        //the position of the players is set
        getPlayer1().setPosition(new Vec2(-20, -22));
        getPlayer2().setPosition(new Vec2(12, -22));

        //the collision listeners for the players are created
        getPlayer1().addCollisionListener(new FootballPickup(ball, ground, wall1, wall2,this,game));
        getPlayer2().addCollisionListener(new FootballPickup(ball, ground, wall1, wall2, this, game));

        //the collision listeners for the walls and floor are created
        ground.addCollisionListener(new FootballPickup(ball, ground, wall1, wall2, this, game));
        wall1.addCollisionListener(new FootballPickup(ball, ground, wall1, wall2, this, game));
        wall2.addCollisionListener(new FootballPickup(ball, ground, wall1, wall2, this, game));
    }

    //sets the winning score for level 1
    @Override
    public boolean isComplete() {
        if (Score1 >= 2)
            return true;
        if (Score2 >= 2)
            return true;
        else;
        return false;
    }
    //sets the background for level 1
    @Override
    public Image paintBackground(){
        Image background = new ImageIcon("data/emirates.png").getImage();
        return background;
    }

    @Override
    public String getLevelName(){
        return "Level1";
    }
    @Override
    public int getScore1() {
        return Score1;
    }
    @Override
    public int getScore2(){
        return Score2;
    }
}


