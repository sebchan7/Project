package game;

import city.cs.engine.*;

import javax.swing.*;


public abstract class Referee extends Walker{

    public BodyImage  image;
    public Shape Shape;
    private int counter = 0;

    public Referee(World w, Shape s) {
        super(w, s);
    }

    public void walkLeft(){
        stopWalking();
        startWalking(-4);
        new java.util.Timer().schedule(
                new java.util.TimerTask() {
                    @Override
                    public void run() {
                        walkRight();
                    }
                },
                5000
        );
    }

    public void walkRight(){
        stopWalking();
        startWalking(4);
        new java.util.Timer().schedule(
                new java.util.TimerTask() {
                    @Override
                    public void run() {
                        walkLeft();
                    }
                },
                5000
        );

    }



//ublic Lion(World world) {
//        super(world, lionShape);
//        addImage(image);
//        startWalking(2);
}


